TOKEN = '6321728835:AAGvmynsv-FMj8KSZWKPebIdj_zLBwtDiok'

keys = {
    'евро' : 'EUR',
    'доллар' : 'USD',
    'рубли' : 'RUB',
}

